package com.Bhavani1.Bhavani1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Bhavani1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
