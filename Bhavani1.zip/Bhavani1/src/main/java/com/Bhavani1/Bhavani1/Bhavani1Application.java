package com.Bhavani1.Bhavani1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Bhavani1Application {

	public static void main(String[] args) {
		SpringApplication.run(Bhavani1Application.class, args);
	}

}
